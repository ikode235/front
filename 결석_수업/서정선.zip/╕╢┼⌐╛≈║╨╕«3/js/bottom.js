var footer = `

<div id="bottom_wrap">
  <footer id="bottom">
      <ul>
          <li><a href="#">중앙회소개</a></li> 
          <li><a href="#">이용약관</a></li> 
          <li><a href="#">개인정보처리방침</a></li>
          <li><a href="#">영상정보처리기기</a></li> 
          <li><a href="#">운영관리 방침</a></li> 
          <li><a href="#">부정비리신고</a></li> 
          <li><a href="#">찾아오시는길</a></li> 
          <li><a href="#">이메일주소 수집거부</a></li> 
          <li><a href="#">원격연결</a></li>           
      </ul>
      <address>
          TEL:(02)2124-3114<br>
07242 서울시 영등포구 은행로 30 (여의도동) 중소기업중앙회
      </address>
      <p>Copyright &copy; 2014 KBIZ All rights Reserved.</p>
  </footer><!--bottom-->
</div><!--bottom_wrap-->

`;
document.write(footer);