var header = `

<div id="top_wrap">
    <div id="notice">
    알려드립니다. 
    본 사이트는 상업적 목적이 아닌
    개인 포트폴리오 용도로 만들어졌습니다.
    홈페이지의 일부내용과 이미지는
    저작권이 따로 있음을 밝혀드립니다.   
    <a href="#">[ 닫기 ]</a>
    </div><!--notice-->   
  <header id="top">
      <h1><a href="index.html"><img src="images/logo.png" alt="KBIZ 중소기업중앙회" width="223" height="25"></a></h1>
      <ul class="quick">
          <li><a href="index.html">홈</a></li>   
          <li><a href="#">로그인</a></li>   
          <li><a href="#">회원가입</a></li>   
          <li><a href="#">사이트맵</a></li>   
          <li><a href="#">이용안내</a></li>   
          <li><a href="#">English</a></li>  
      </ul><!--quick-->    
      <nav id="main_navi">
          <ul>
              <li><a href="menu1.html">정보마당</a></li> 
              <li><a href="menu2.html">지원사업</a></li> 
              <li><a href="#">공제사업</a></li> 
              <li><a href="#">인력지원</a></li> 
              <li><a href="#">상담센터</a></li> 
              <li><a href="#">커뮤니티</a></li> 
              <li><a href="#">중앙회</a></li> 
              <li><a href="#">협동조합</a></li>
          </ul>
      </nav><!--main_navi-->    
  </header><!--top-->    
</div><!--top_wrap 상단전체-->    

`;
document.write(header);